import logging
import asyncio
from typing import List, Dict, Any, Optional
from app.combined_chat.gemini_service import GeminiService
from app.combined_chat.embedding_service import EmbeddingService
from app.combined_chat.gds_service import GDSCombinedService
from app.db.connections import get_neo4j_driver, get_redis_client
import json
import time

logger = logging.getLogger(__name__)

class CombinedRAGService:
    def __init__(self):
        self.gemini = GeminiService()
        self.vector_engine = EmbeddingService()
        self.gds_suite = GDSCombinedService()
        self.neo4j = get_neo4j_driver()
        self.redis = get_redis_client()
        self._schema_cache: Optional[str] = None
        self._schema_expiry: float = 0
        self._greetings = {"hi", "hello", "hey", "hola", "greetings", "good morning", "good afternoon", "good evening"}

    async def stream_answer(self, question: str, folder_id: Optional[str] = None, file_id: Optional[str] = None, history: Optional[List[Dict[str, str]]] = None, user_id: str = "anonymous"):
        """🚀 Streaming Orchestrator with Strict Folder Isolation."""
        
        # 1. Analyzing (History & Schema)
        logger.info(f"🚀 Research starting for folder {folder_id or 'global'} | Question: {question}")
        yield json.dumps({"type": "step", "id": 1, "status": "Analyzing research intent..."}) + "\n"
        history_key = f"chat:history:{user_id}:{folder_id or 'global'}"
        stored_history = []
        try:
            raw_history = await self.redis.lrange(history_key, -10, -1)
            stored_history = [json.loads(m) for m in raw_history]
        except Exception as e:
            logger.warning(f"Failed to load history from Redis: {e}")

        combined_history = (stored_history + history) if history else stored_history
        
        # Fast Path: Greeting Detector
        clean_q = question.lower().strip().strip('?!.')
        if clean_q in self._greetings:
            full_ans = "Hello! I am your Neural Nexus research assistant. I'm focused strictly on the data in your active folder. How can I help?"
            yield json.dumps({"type": "content", "data": full_ans}) + "\n"
            yield json.dumps({"type": "step", "id": 4, "status": "Done"}) + "\n"
            return

        # Step 1 continued (Schema)
        schema = await self._get_schema()
        
        # Step 1 continued (Intent)
        orchestration_task = asyncio.create_task(self._orchestrate_retrieval(question, schema, folder_id or "global"))
        vector_task = asyncio.create_task(self.vector_engine.vector_search(question, folder_id))
        
        intent = await orchestration_task
        logger.info(f"🧠 Research Intent: {intent.get('research_strategy', 'Standard')}")
        if intent.get("cypher_query"):
            logger.info(f"🔗 Generated Cypher: {intent['cypher_query']}")
        
        yield json.dumps({"type": "intent", "data": intent}) + "\n"

        # 2. Searching
        logger.info(f"🔍 Retrieval Phase Starting | Sources: Vector={True}, Graph={intent.get('use_cypher')}, GDS={intent.get('use_gds')}")
        yield json.dumps({"type": "step", "id": 2, "status": "Searching the knowledge graph..."}) + "\n"
        
        # Collect results with explicit labels for proper fusion
        named_tasks = [("Semantic Search", vector_task)]
        
        # 1. Cypher Execution (with Injection)
        if intent.get("use_cypher") and intent.get("cypher_query"):
            named_tasks.append(("Graph Traversal", self._execute_cypher(intent["cypher_query"], folder_id, file_id)))
        
        # 2. GDS Algorithm Execution
        if intent.get("use_gds"):
            algo = intent.get("gds_algo", "centrality")
            try:
                gds_task = None
                if algo == "similarity":
                    gds_task = self.gds_suite.get_similarity_context(folder_id or "global")
                elif algo == "community":
                    gds_task = self.gds_suite.get_community_context(folder_id or "global")
                elif algo == "paths":
                    gds_task = self.gds_suite.get_path_context("", "", folder_id or "global")
                else:
                    gds_task = self.gds_suite.get_centrality_context(folder_id or "global")
                
                if gds_task:
                    named_tasks.append((f"Graph Algorithm ({algo})", gds_task))
            except Exception as e:
                logger.error(f"GDS Task Prep Failed: {e}")

        # Wait for all Retrieval outputs
        names = [t[0] for t in named_tasks]
        tasks = [t[1] for t in named_tasks]
        raw_outputs = await asyncio.gather(*tasks)
        
        # Fuse with labels
        fused = []
        for name, result in zip(names, raw_outputs):
            if result:
                if isinstance(result, list):
                    res_str = json.dumps(result[:20], indent=2, default=str)
                    if name.startswith("Graph Algorithm"):
                        current_algo = algo if 'algo' in locals() else "analytics"
                        yield json.dumps({"type": "gds_results", "data": {"algorithm": current_algo, "results": result}}) + "\n"
                else:
                    res_str = str(result)
                fused.append(f"=== {name} ===\n{res_str}")
        
        context = "\n\n".join(fused)
        logger.info(f"🧪 Context Fusion Complete | Total Sources: {len(fused)} | Data Size: {len(context)} chars")
        
        # 3. Synthesizing
        yield json.dumps({"type": "step", "id": 3, "status": "Synthesizing research results..."}) + "\n"
        
        full_answer = ""
        prompt = f"""
        You are the **Neural Nexus Research Assistant**.
        
        STRICT CONTEXT RULE: 
        Base your answer ONLY on the provided context below. This data is from the user's ACTIVE FOLDER. 
        DO NOT use any prior knowledge or data from other "folders" or projects.
        
        CONTEXT FROM ACTIVE FOLDER:
        {context}
        
        USER QUESTION: 
        {question}
        
        INSTRUCTIONS:
        1. Character: Professional Expert & Data Scientist.
        2. Strictly mention ONLY items found in the context.
        3. Characterize relationships based on the Graph Traversal results.
        4. GDS ALGORITHMS: If "Graph Algorithm" data is provided (e.g., Centrality, Louvain), you MUST provide a distinct "⚡ Algorithmic Insights" section. Clearly break down the hidden patterns, statistical significance, rankings, or communities it found.
        5. Output Format: Executive Summary + ⚡ Algorithmic Insights (if GDS was run) + Data Table. 
        6. Clean UI: Do NOT include a "Source of Information" column or mention the specific data source/method (e.g., "From Graph Traversal"). Just present the verified facts naturally.
        """
        
        async for chunk in self.gemini.astream_response(prompt, combined_history):
            full_answer += chunk
            yield json.dumps({"type": "content", "data": chunk}) + "\n"
        
        # 4. Finalizing
        logger.info(f"✅ Research completed for user {user_id}")
        yield json.dumps({"type": "step", "id": 4, "status": "Research completed."}) + "\n"
        try:
            await self.redis.rpush(history_key, json.dumps({"role": "user", "content": question}))
            await self.redis.rpush(history_key, json.dumps({"role": "assistant", "content": full_answer}))
            await self.redis.ltrim(history_key, -20, -1) 
            await self.redis.expire(history_key, 86400) 
        except Exception as e:
            logger.warning(f"Failed to save history: {e}")

    async def answer(self, question: str, folder_id: Optional[str] = None, file_id: Optional[str] = None, history: Optional[List[Dict[str, str]]] = None, user_id: str = "anonymous") -> Dict[str, Any]:
        """Non-streaming wrapper for backward compatibility."""
        full_answer = ""
        intent = {}
        async for chunk_raw in self.stream_answer(question, folder_id, file_id, history, user_id):
            chunk = json.loads(chunk_raw.strip())
            if chunk["type"] == "content":
                full_answer += chunk["data"]
            elif chunk["type"] == "intent":
                intent = chunk["data"]
        
        return {
            "answer": full_answer,
            "intent": intent,
            "context_summary": f"Retrieved from folder {folder_id or 'global'}."
        }

    async def _get_schema(self) -> str:
        if self._schema_cache and time.time() < self._schema_expiry:
            return str(self._schema_cache)
            
        async with self.neo4j.session() as session:
            try:
                # 1. Get Node Labels & Properties
                node_props_res = await session.run("""
                    CALL db.labels() YIELD label 
                    MATCH (n) WHERE label IN labels(n) 
                    WITH label, keys(n) AS keys LIMIT 100
                    RETURN label, collect(DISTINCT keys) AS property_samples
                """)
                node_data = await node_props_res.data()
                label_info = [f"Node Label: {r['label']} (Props: {r['property_samples']})" for r in node_data]
                
                # 2. Get Relationship Types (Directly)
                rel_res = await session.run("CALL db.relationshipTypes() YIELD relationshipType RETURN relationshipType")
                rel_data = await rel_res.data()
                rel_types = [r['relationshipType'] for r in rel_data]
                rel_prop_info = [f"Available Rel Type: {t}" for t in rel_types]

                # 3. Get Relationship Property Samples (Sampled)
                rel_props_res = await session.run("""
                    MATCH ()-[r]->() 
                    WITH type(r) AS type, keys(r) AS keys LIMIT 100
                    RETURN type, collect(DISTINCT keys) AS property_samples
                """)
                rel_prop_data = await rel_props_res.data()
                rel_prop_info += [f"Rel Type {r['type']} Props: {r['property_samples']}" for r in rel_prop_data]

                # 3. Get Active Patterns
                patterns_res = await session.run("""
                    CALL db.schema.visualization() YIELD relationships
                    UNWIND relationships AS rel
                    WITH startNode(rel) AS s, type(rel) AS t, endNode(rel) AS e
                    RETURN DISTINCT labels(s)[0] AS source, t AS type, labels(e)[0] AS target
                """)
                pattern_data = await patterns_res.data()
                patterns = [f"({r['source']})-[:{r['type']}]->({r['target']})" for r in pattern_data]
                
                res_str = "KNOWLEDGE GRAPH SCHEMA (GROUND TRUTH):\n"
                res_str += "\n".join(label_info) + "\n"
                res_str += "\n".join(rel_prop_info) + "\n"
                res_str += "\nValidated connection Patterns:\n" + "\n".join(patterns)
                
                logger.info(f"📊 Schema Discovery: Found {len(label_info)} labels and {len(rel_types)} relationship types.")
                
                self._schema_cache = res_str
                self._schema_expiry = time.time() + 300
                return res_str
            except Exception as e:
                logger.error(f"Schema discovery failed: {e}")
                return "Labels: [Unknown], Patterns: [Unknown]"

    async def _orchestrate_retrieval(self, question: str, schema: str, folder_id: str) -> Dict[str, Any]:
        prompt = f"""
        TASK: Orchestrate data retrieval for a Knowledge Graph Research Agent.
        FOLDER_ID: {folder_id}
        SCHEMA:
        {schema}
        
        SOP FOR COMPLEX GRAPH RESEARCH:
        1. PATH DISCOVERY: For "X treats Y" or "X connected to Y", use 2-3 hop Cypher: (n)-[*1..3]->(m).
        2. IMPORTANCE/RANKING (*GDS MANDATORY*): For "most important", "widest range", or "top entities", you MUST set `use_gds` to true and select `centrality`.
        3. GROUPS/CLUSTERS (*GDS MANDATORY*): For "groups of diseases" or "clusters", you MUST set `use_gds` to true and select `community`.
        4. DEGREE FALLBACK: Use Neo4j 5 syntax if sorting in Cypher: MATCH (n) WHERE n.folder_id = '{folder_id}' RETURN n.name, COUNT {{ (n)--() }} as deg ORDER BY deg DESC.
        5. DIVERSITY: count(DISTINCT neighbor) of a target label.
        6. SIMILARITY: Find nodes sharing neighbors (hubs). (a)-[:REL]->(hub)<-[:REL]-(b).
        7. STRUCTURE SIMILARITY: Use [SIMILAR_TO] relationships and the 'basis' property if present.
        8. PLANT PARTS: Use the 'part_of_plant' property on Relationships if filtering by plant organ.

        STRICT CYPHER RULES:
        - FOLDER ISOLATION: EVERY node variable in your MATCH must be filtered by folder_id. 
          Example: MATCH (h:Herb), (p:Phytochemical) WHERE h.folder_id = '{folder_id}' AND p.folder_id = '{folder_id}' ...
        - NO HALLUCINATIONS: You MUST ONLY use Relationship Types listed in the SCHEMA above. 
          (e.g., if SCHEMA has HAS_USE, do NOT use HAS_THERAPEUTIC_USE).
        - MULTI-HOP PATHS: If the question requires connecting A to C, and A is connected to B and B to C, use (a)-[*1..3]->(c) or explicit hops.
        - NEO4J 5 SYNTAX: Do NOT use `size((n)--())`. You MUST use the `COUNT {{ (n)--() }}` subquery pattern instead.
        - No Hardcoding: Use labels and property comparisons.

        Question: {question}
        
        JSON OUTPUT:
        {{
          "use_cypher": bool,
          "cypher_query": "CYPHER",
          "use_gds": bool,
          "gds_algo": "centrality|community|similarity|null",
          "research_strategy": "..."
        }}
        """
        try:
            return await self.gemini.generate_json(prompt)
        except Exception as e:
            logger.error(f"Orchestration failed: {e}")
            return {"use_cypher": False, "cypher_query": None, "use_gds": False, "gds_algo": None, "research_strategy": "Fallback"}

    async def _execute_cypher(self, cypher: str, folder_id: str, file_id: Optional[str] = None) -> str:
        if not cypher: return ""
        cypher = cypher.replace('```cypher', '').replace('```', '').strip()
        
        # Security: Blocking Write Ops
        if any(keyword in cypher.upper() for keyword in ["CREATE", "DELETE", "SET", "MERGE", "REMOVE"]):
             return "[Security Error]: Write operations blocked."

        try:
            async with self.neo4j.session() as session:
                res = await session.run(cypher)
                data = await res.data()
                logger.info(f"📊 Cypher Success | Results: {len(data)} nodes/paths found.")
                return f"[Graph Results (Scoped to Folder {folder_id})]:\n{json.dumps(data, indent=2, default=str)[:4000]}"
        except Exception as e:
            logger.error(f"❌ Cypher Execution Failed: {str(e)}")
            return f"[Graph Error]: {str(e)}"
